using System.ComponentModel.DataAnnotations;

namespace StudentApp.Models
{
    public class Student
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "შეიყვანე სახელი")]
        [Display(Name = "სახელი")]
        public string Name { get; set; }

        [Required(ErrorMessage = "შეიყვანე ემაილი")]
        [EmailAddress(ErrorMessage = "ემაილი არასწორია")]
        [Display(Name = "ემაილი")]
        public string Email { get; set; }

        [Range(1, 120, ErrorMessage = "ასაკი უნდა იყოს 1-დან 120-მდე")]
        [Display(Name = "ასაკი")]
        public int Age { get; set; }
    }
}
